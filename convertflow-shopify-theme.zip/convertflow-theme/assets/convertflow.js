/* ══════════════════════════════════════
   ConvertFlow Shopify Theme — convertflow.js
   ══════════════════════════════════════ */

const conversions = [
  { from:'PDF',        to:'Word',        icon:'📄', type:'pdf',   desc:'Convert PDF documents to editable Word files' },
  { from:'PDF',        to:'Excel',       icon:'📊', type:'pdf',   desc:'Extract tables from PDFs into spreadsheets' },
  { from:'PDF',        to:'PowerPoint',  icon:'📑', type:'pdf',   desc:'Turn PDFs into editable presentations' },
  { from:'PDF',        to:'JPG',         icon:'🖼️', type:'pdf',   desc:'Convert PDF pages to high-quality images' },
  { from:'Word',       to:'PDF',         icon:'📝', type:'word',  desc:'Save Word documents as professional PDFs' },
  { from:'Word',       to:'PowerPoint',  icon:'🎯', type:'word',  desc:'Transform Word content into slides' },
  { from:'Word',       to:'HTML',        icon:'🌐', type:'word',  desc:'Convert Word docs to web-ready HTML' },
  { from:'Excel',      to:'PDF',         icon:'📊', type:'excel', desc:'Export Excel sheets as PDF documents' },
  { from:'Excel',      to:'PowerPoint',  icon:'📈', type:'excel', desc:'Turn spreadsheets into slide decks' },
  { from:'Excel',      to:'CSV',         icon:'🗃️', type:'excel', desc:'Export Excel data as CSV files' },
  { from:'PowerPoint', to:'PDF',         icon:'🎨', type:'ppt',   desc:'Save presentations as PDF files' },
  { from:'PowerPoint', to:'Word',        icon:'📋', type:'ppt',   desc:'Extract slide content to Word docs' },
  { from:'JPG',        to:'PDF',         icon:'🖼️', type:'image', desc:'Combine images into a single PDF' },
  { from:'PNG',        to:'JPG',         icon:'🎑', type:'image', desc:'Convert PNG images to JPG format' },
  { from:'HTML',       to:'PDF',         icon:'🌐', type:'other', desc:'Convert web pages to PDF documents' },
  { from:'TXT',        to:'PDF',         icon:'📃', type:'other', desc:'Turn plain text files into PDFs' },
];

function buildGrid() {
  const grid = document.getElementById('convertersGrid');
  if (!grid) return;
  conversions.forEach((c, i) => {
    const card = document.createElement('div');
    card.className = `conv-card ${c.type}`;
    card.style.animationDelay = (i * 0.04) + 's';
    card.innerHTML = `
      <div class="conv-icon ${c.type}">${c.icon}</div>
      <div class="conv-info">
        <div class="conv-title">${c.from} → ${c.to}</div>
        <div class="conv-desc">${c.desc}</div>
      </div>
      <div class="conv-arrow">›</div>
    `;
    card.onclick = () => openModal(c);
    grid.appendChild(card);
  });
}

function openModal(conv) {
  const iconBg = {
    pdf:   'rgba(255,50,50,0.12)',
    word:  'rgba(0,120,255,0.12)',
    excel: 'rgba(0,180,80,0.12)',
    ppt:   'rgba(255,120,0,0.12)',
    image: 'rgba(180,0,255,0.12)',
    other: 'rgba(0,200,200,0.12)'
  };
  const icon = document.getElementById('modalIcon');
  icon.textContent = conv.icon;
  icon.style.background = iconBg[conv.type] || iconBg.other;
  document.getElementById('modalTitle').textContent = `${conv.from} to ${conv.to}`;
  document.getElementById('modalDesc').textContent = conv.desc + '. Upload your file and click Convert Now to get started.';
  document.getElementById('fileInfo').textContent = '';
  document.getElementById('progressBar').style.display = 'none';
  document.getElementById('progressFill').style.width = '0%';
  document.getElementById('modalFile').value = '';
  document.getElementById('modalOverlay').classList.add('active');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active');
}

function handleModalFile(input) {
  if (input.files[0]) {
    document.getElementById('fileInfo').textContent = '📎 ' + input.files[0].name;
  }
}

function handleFileSelect(input) {
  if (input.files[0]) {
    showToast('📎 File selected: ' + input.files[0].name + ' — choose conversion format and click Convert!');
  }
}

function startConvert() {
  const bar  = document.getElementById('progressBar');
  const fill = document.getElementById('progressFill');
  bar.style.display = 'block';
  let p = 0;
  const iv = setInterval(() => {
    p += Math.random() * 18 + 5;
    if (p >= 100) {
      p = 100;
      clearInterval(iv);
      setTimeout(() => {
        closeModal();
        showToast('✅ Conversion complete! Your file is ready to download.');
      }, 400);
    }
    fill.style.width = p + '%';
  }, 200);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 4000);
}

// Drag & drop on main dropzone
document.addEventListener('DOMContentLoaded', function () {
  buildGrid();

  const dz = document.getElementById('mainDrop');
  if (dz) {
    ['dragover','dragenter'].forEach(e =>
      dz.addEventListener(e, ev => { ev.preventDefault(); dz.classList.add('drag-over'); })
    );
    ['dragleave','drop'].forEach(e =>
      dz.addEventListener(e, ev => {
        ev.preventDefault();
        dz.classList.remove('drag-over');
        if (ev.dataTransfer && ev.dataTransfer.files[0]) {
          showToast('📎 ' + ev.dataTransfer.files[0].name + ' — select your output format!');
        }
      })
    );
  }

  // Close modal on backdrop click
  const overlay = document.getElementById('modalOverlay');
  if (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === this) closeModal();
    });
  }
});
